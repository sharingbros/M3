package seleniumdemo;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestForHotelBooking {
	static WebDriver driver;

	@BeforeClass
	public static void createWebDriver() {
		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("file:///C:/Users/patukuri/Desktop/App/hotelbooking.html");

	}

	@Test
	public void testLastName() {
		WebElement element = driver.findElement(By.xpath("//input[@id='txtLastName']"));
		element.sendKeys("Chaturvedula");
	}

	@Test
	public void testFisrtname() {
		WebElement element = driver.findElement(By.xpath("//input[@type='text']"));
		element.sendKeys("Abhilash");
	}

	@Test
	public void testEmail() {
		WebElement element = driver.findElement(By.id("txtEmail"));
		element.sendKeys("pavansai408@gmail.com");
	}

	@Test
	public void testPhno() {
		WebElement element = driver.findElement(By.xpath("//input[@name='Phone']"));
		element.sendKeys("9341714217");
	}

	@Test
	public void testCardHolderName() {
		WebElement element = driver.findElement(By.xpath("//input[@id='txtCardholderName']"));
		element.sendKeys("pavan");

	}

	@Test
	public void testCardNumber() {

		WebElement element = driver.findElement(By.xpath("//input[@id='txtDebit']"));
		element.sendKeys("468817198523694");

	}
	@Test
	public void testCvv() {

		WebElement element = driver.findElement(By.xpath("//input[@id='txtCvv']"));
		element.sendKeys("694");

	}

	// element.clear();
	// element.sendKeys("Chaturvedula");

	/*
	 * @Test public void test() {
	 * driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Capgemini12")
	 * ; WebElement element = driver.findElement(By.xpath("//input[@type='text']"));
	 * element.clear(); element.sendKeys("Abhilash"); }
	 */

	/*
	 * @AfterClass public void closeBrowser() {
	 * 
	 * driver.close(); }
	 */

}
