package seleniumdemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		// to maximize the screen
		driver.manage().window().maximize();
		driver.navigate().to("file:///C:/Users/patukuri/Desktop/App/hotelbooking.html");
		// implicit wait statement
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//explicit wait
		//we can use multiple explicit wait statements
		WebDriverWait wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.alertIsPresent());
		Alert alt = driver.switchTo().alert();
		System.out.println(alt.getText());
		alt.accept();
		
	}

}
