package seleniumdemo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.navigate().to("file:///C:/Users/patukuri/Desktop/App/hotelbooking.html");

		String actualHeading = driver.findElement(By.xpath("//h2")).getText();
		System.out.println(actualHeading);

		String testHeading = "Hotel Booking Form";

		String attribute = driver.findElement(By.id("txtEmail")).getAttribute("name");
		System.out.println(attribute);

		/*driver.findElement(By.id("txtEmail")).sendKeys("capgemini");
		String attval = driver.findElement(By.id("txtEmail")).getAttribute("value");
*/
		//System.out.println(attval);
		driver.findElement(By.id("txtEmail")).sendKeys("capgemini");
	    driver.findElement(By.id("txtLastName")).sendKeys("pavan@capgemini.com");
	    driver.findElement(By.id("btnPayment")).click();

		Alert alt = driver.switchTo().alert();
		System.out.println(alt.getText());
		alt.accept();
		//alt.dismiss();
	}

}
