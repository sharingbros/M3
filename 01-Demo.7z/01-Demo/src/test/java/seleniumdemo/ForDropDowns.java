package seleniumdemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ForDropDowns {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		// to maximize the screen
		driver.manage().window().maximize();
		driver.navigate().to("file:///C:/Users/patukuri/Desktop/App/hotelbooking.html");
		// implicit wait statement
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		WebElement city = driver.findElement(By.name("city"));

		Select select = new Select(city);
		// three methods avialble in select class
		// select.selectByVisibleText("Hyderabad");
		// select.selectByValue("Bangalore");
		select.selectByIndex(1);
		WebElement state = driver.findElement(By.name("state"));
		Select select1 = new Select(state);
		select1.selectByIndex(1);
		// driver.quit();
		// select1.deselectAll();
		// select.deselectAll();
		// gives true(or)false select.isMultiple();
	}

}
