package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumDemo1 {

	public static void main(String[] args) {
		// Step1-open browser

		/* WebDriver driver=new FirefoxDriver(); */

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// Step2-naviagte to application

		driver.get("C:/Users/patukuri/Desktop/App/login.html");
		// Step3-enter user name(find the element and perform action)
		// driver.findElement(By.name("userName")).sendKeys("Capgemini");
		// driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Capgemini12");
		WebElement pass1 = driver.findElement(By.name("userName"));
		pass1.clear();
		pass1.sendKeys("ca1");
		// Step4-enter password
		// driver.findElement(By.name("userPwd")).sendKeys("Pavan");
		/*
		 * driver.findElement(By.xpath("//input[@type='password']")).sendKeys(
		 * "123456789");
		 */
		WebElement pass = driver.findElement(By.name("userPwd"));
		pass.clear();
		pass.sendKeys("Ca");
		// Step5-hit login
		// driver.findElement(By.className("btn")).click();
		// driver.findElement(By.xpath("//input[@class='btn']")).click();
		WebElement pass2 = driver.findElement(By.className("btn"));
		pass2.click();
		// Step6-close browser
		// driver.close();

	}

}
