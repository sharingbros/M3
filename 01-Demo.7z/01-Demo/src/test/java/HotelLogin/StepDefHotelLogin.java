package HotelLogin;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefHotelLogin {

	
	@Given("^User is on login page$")
	public void user_is_on_login_page()  {
	   
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page()  {
	   
	}

	@Then("^check the heading of the UserName entry$")
	public void check_the_heading_of_the_UserName_entry()  {
	   
	}

	@Then("^check the heading of the Password entry$")
	public void check_the_heading_of_the_Password_entry()  {
	    
	}

	@Then("^check the name of login button$")
	public void check_the_name_of_login_button()  {
	    
	}

	@When("^user enters valid username and pasword$")
	public void user_enters_valid_username_and_pasword()  {
	   
	}

	@Then("^check both username and password matches$")
	public void check_both_username_and_password_matches()  {
	   
	}

	@When("^user enters invalidusername and pasword$")
	public void user_enters_invalidusername_and_pasword()  {
	  
	}

	@When("^clicks the login button$")
	public void clicks_the_login_button()  {
	  
	}

	@Then("^display appropriate error message$")
	public void display_appropriate_error_message()  {
	    
	}

	@When("^user enters username and invalid password$")
	public void user_enters_username_and_invalid_password()  {
	   
	}

	@When("^user enters valid username and password$")
	public void user_enters_valid_username_and_password()  {
	  
	}

	@When("^user clicks on login button$")
	public void user_clicks_on_login_button()  {
	  
	}

	@Then("^naviagte to the correct page$")
	public void naviagte_to_the_correct_page()  {
	  
	}

	@When("^user enters valid username, valid password$")
	public void user_enters_valid_username_valid_password() {
	  
	}

	@Then("^navigate to hotelbooking$")
	public void navigate_to_hotelbooking()  {
	   
	}

	@When("^user don't enter either username or password$")
	public void user_don_t_enter_either_username_or_password()  {
	   
	}

	@When("^user enters a valid username but invalid password$")
	public void user_enters_a_valid_username_but_invalid_password() {
	   
	}

	
}
