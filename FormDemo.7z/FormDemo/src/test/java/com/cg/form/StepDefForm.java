package com.cg.form;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.factory.FormPageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefForm {
	static FormPageFactory formPageFactory;
	static WebDriver driver;


	@Given("^user is on  page$")
	public void user_is_on_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mpasumar\\Desktop\\BDD Jar files\\chromedriver.exe");
		driver = new ChromeDriver();
		formPageFactory = new FormPageFactory(driver);
		driver.get("file:///C:/Users/mpasumar/Desktop/registration1.html");
		
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		if (title.equals("Registration")) {
			System.err.println("matched");
		} else {
			System.err.println("not matched");
		}

	}

	@When("^name is empty$")
	public void name_is_empty() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		formPageFactory.setName(" ");
		Thread.sleep(1000);
		formPageFactory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.err.println("not matched" + alertMessage);
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		driver.close();
	}

	@When("^user entered invalid name")
	public void user_entered_invalid_name_name(DataTable name1) throws Throwable {

		Thread.sleep(1000);
		List<String> nameList = name1.asList(String.class);
		String data = null;
		for (String name : nameList) {
			data = name;
			formPageFactory.getName().clear();
			formPageFactory.setName(name);
			Thread.sleep(1000);
			formPageFactory.setButton();

			if (data.matches("^[A-Za-z]{3,10}$")) {
				System.err.println("matching");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.err.println("not matched" + alertMessage);
			}
		}
	}

	@When("^mobile is empty$")
	public void mobile_is_empty() throws Throwable {
		formPageFactory.setName("mahalakshmi");
		Thread.sleep(1000);
		formPageFactory.setEmail("maha@gmail.com");
		Thread.sleep(1000);
		formPageFactory.setPhone("");
		formPageFactory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.err.println("not matched" + alertMessage);
	}

	@When("^email is empty$")
	public void email_is_empty() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		formPageFactory.setName("maha");
		Thread.sleep(1000);
		formPageFactory.setEmail("");
		Thread.sleep(1000);
		formPageFactory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.err.println("not matched" + alertMessage);

	}

	@When("^address is empty$")
	public void address_is_empty() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		formPageFactory.setName("mahalakshmi");
		Thread.sleep(1000);
		formPageFactory.setEmail("maha@gmail.com");
		Thread.sleep(1000);
		formPageFactory.setPhone("9087654321");
		Thread.sleep(1000);
		formPageFactory.setAddress("");
		Thread.sleep(1000);
		formPageFactory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.err.println("not matched" + alertMessage);
	}

	
	@When("^user entered invalid mobile number")
	public void user_entered_invalid_mobile_number_mobile(DataTable arg1) throws Throwable {

		formPageFactory.setName("Mahalakshmi");
		Thread.sleep(1000);
		formPageFactory.setEmail("maha@gmail.com");
		Thread.sleep(1000);
		List<String> phoneList = arg1.asList(String.class);
		String data = null;
		for (String phone : phoneList) {
			data = phone;
			formPageFactory.getPhone().clear();
			formPageFactory.setPhone(phone);
			Thread.sleep(1000);
			formPageFactory.setButton();

			if (data.matches("^[7-9]{1}[0-9]{9}$")) {
				System.err.println("matching");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.err.println("not matched" + alertMessage);
			}
		}
	}

	@When("^user enters valid data$")
	public void user_enters_valid_data() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		formPageFactory.setName("Mahalakshmi");
		Thread.sleep(1000);
		formPageFactory.setEmail("maha@gmail.com");
		Thread.sleep(1000);
		formPageFactory.setPhone("9087654321");
		Thread.sleep(1000);
		formPageFactory.setAddress("chennai");
		Thread.sleep(1000);
		formPageFactory.setGender1();
		Thread.sleep(1000);
		formPageFactory.setButton();
	}

	@When("^user entered invalid Email")
	public void user_entered_invalid_Email(DataTable arg1) throws Throwable {
		formPageFactory.setName("Mahalakshmi");
		Thread.sleep(1000);
		List<String> emailList = arg1.asList(String.class);
		String data = null;
		for (String email : emailList) {
			data = email;
			formPageFactory.getEmail().clear();
			formPageFactory.setEmail(email);
			Thread.sleep(1000);
			formPageFactory.setButton();

			if (data.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$")) {
				System.err.println("matching");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.err.println("not matched" + alertMessage);
			}
		}
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {

		System.err.println("registered successfully");
		driver.close();
	}

}
