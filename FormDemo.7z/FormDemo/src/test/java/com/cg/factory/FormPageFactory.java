package com.cg.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FormPageFactory {
	WebDriver wd;

	public FormPageFactory(WebDriver webDriver) {
		this.wd = webDriver;
		PageFactory.initElements(wd, this);
	}

	public FormPageFactory() {

	}

	@FindBy(id = "txtName")
	@CacheLookup
	WebElement name;

	@FindBy(id = "txtEmail")
	@CacheLookup
	WebElement email;

	@FindBy(id = "txtPhone")
	@CacheLookup
	WebElement Phone;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[4]/td[2]/textarea")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="male")
	@CacheLookup
	WebElement gender1;
	
	@FindBy(id="female")
	@CacheLookup
	WebElement gender2;

	public WebElement getGender1() {
		return gender1;
	}

	public void setGender1() {
		gender1.click();
	}

	public WebElement getGender2() {
		return gender2;
	}

	public void setGender2() {
		gender2.click();
	}

	@FindBy(className = "btn")
	@CacheLookup
	WebElement button;

	public WebDriver getWd() {
		return wd;
	}

	public void setWd(WebDriver wd) {
		this.wd = wd;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String nameTemp) {
		name.sendKeys(nameTemp);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String emailTemp) {
		email.sendKeys(emailTemp);
	}

	public WebElement getPhone() {
		return Phone;
	}

	public void setPhone(String phoneTemp) {
		Phone.sendKeys(phoneTemp);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String addressTemp) {
		address.sendKeys(addressTemp);
	}

	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

}
