package feature;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	static WebDriver driver = new FirefoxDriver();
	
	PageFactorForFeature factory = new PageFactorForFeature(driver);
	
	static String alertMessage;
	
	
	@Given("^user is on home page$")
	public void user_is_on_home_page() throws Throwable {
		
		driver.navigate().to("file:///C:/Users/abhchatu/Desktop/Task2.html");
		
	}

	@When("^title is Task(\\d+)$")
	public void title_is_Task(int arg1) throws Throwable {
	   String title1 = driver.getTitle();
	   String title2= "Task2";
	   assertEquals(title2, title1);
	   		
	}

	@Then("^display message$")
	public void display_message() throws Throwable {
	    
		System.out.println("user is on home page");
	}

	@Given("^User is task(\\d+) page$")
	public void user_is_task_page(int arg1) throws Throwable {
	
		driver.navigate().to("file:///C:/Users/abhchatu/Desktop/Task2.html");

	}

	@When("^user enters name$")
	public void user_enters_name(DataTable arg1) throws Throwable {
		
		factory.getPhoneNumber().clear();
		factory.setPhoneNumber("9966549675");
		Thread.sleep(1000);
		
		factory.getEmail().clear();
		factory.setEmail("abhilash@gmail.com");
		Thread.sleep(1000);
		
		factory.getAddr().clear();
		factory.setAddr("Kadapa");
		Thread.sleep(1000);
		
		factory.setGender2();
		
		factory.getName().clear();
		
		List<String> names=arg1.asList(String.class);
		String data=null;
		for (String name1:names) {
			data=name1;
			if(data.matches("^[A-Z]{1}[a-z]{7}$ ")) {
			System.out.println("Matched...!");				
			}			
			else
			{
				System.out.println("not matched...!");
				/*alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();*/
			}
			
			factory.getName().clear();
			factory.setName(data);
			Thread.sleep(1000);
			factory.setButton();
			Thread.sleep(1000);
			alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
		
		}				
	}

	@Then("^display name message$")
	public void display_name_message() throws Throwable {
		
		 factory.setButton();
		
		alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		
	}

	@Given("^user is on task(\\d+) page$")
	public void user_is_on_task_page(int arg1) throws Throwable {
		driver.navigate().to("file:///C:/Users/abhchatu/Desktop/Task2.html");
	}

	@When("^user enters mobile number$")
	public void user_enters_mobile_number(DataTable arg1) throws Throwable {
		
		factory.getName().clear();
		factory.setName("Abhilash");
		Thread.sleep(1000);
		
		factory.getEmail().clear();
		factory.setEmail("abhilash@gmail.com");
		Thread.sleep(1000);
		
		factory.getAddr().clear();
		factory.setAddr("Kadapa");
		Thread.sleep(1000);
		
		factory.setGender1();
		
		factory.getPhoneNumber().clear();
		
		List<String> phoneNum=arg1.asList(String.class);
		String data=null;
		for (String phoneNumber:phoneNum) {
			data=phoneNumber;
			if(data.matches("^[7-9]{1} [0-9]{9}$ ")) {
				System.out.println("Matched...!");				
				}			
			else
			{
				System.out.println("not matched...!");
				/*alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();*/
			}
			
			factory.getPhoneNumber().clear();
			factory.setPhoneNumber(data);
			Thread.sleep(1000);
			factory.setButton();
			Thread.sleep(1000);
			alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
		
		}				
	}

	@Then("^display mobile number message$")
	public void display_mobile_number_message() throws Throwable {
		System.out.println("Matched!! Successfully");
	}

	@Given("^User is on task(\\d+) page$")
	public void user_is_on_task_page1(int arg1) throws Throwable {
		driver.navigate().to("file:///C:/Users/abhchatu/Desktop/Task2.html");
	}

	@When("^user enters email id$")
	public void user_enters_email_id(DataTable arg1) throws Throwable {

		factory.getName().clear();
		factory.setName("Abhilash");
		Thread.sleep(1000);
		
		factory.getPhoneNumber().clear();
		factory.setPhoneNumber("9876543221");;
		Thread.sleep(1000);
		
		factory.getAddr().clear();
		factory.setAddr("Kadapa");
		Thread.sleep(1000);
		
		factory.setGender2();
		
		factory.getEmail().clear();
		
		List<String> eMail=arg1.asList(String.class);
		String data=null;
		for (String email:eMail) {
			data=email;
			if(data.matches("^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$")) {
				System.out.println("Matched...!");				
				}			
			else
			{
				System.out.println("not matched...!");
				/*alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();*/
			}
			
			factory.getEmail().clear();
			factory.setEmail(data);
			Thread.sleep(1000);
			factory.setButton();
			Thread.sleep(1000);
			alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
		
		}				
	}

	@Then("^display emailId message$")
	public void display_emailId_message() throws Throwable {
	    System.out.println("Matched Successfully");
	}

	@When("^user selects gender$")
	public void user_selects_gender() throws Throwable {
		
		factory.getName().clear();
		factory.setName("Abhilash");
		Thread.sleep(1000);
				
		factory.getPhoneNumber().clear();
		factory.setPhoneNumber("9876543221");;
		Thread.sleep(1000);
		
		factory.getEmail().clear();
		factory.setEmail("abhilash@gmail.com");
		Thread.sleep(1000);
		
		
		factory.getAddr().clear();
		factory.setAddr("Kadapa");
		Thread.sleep(1000);
	
		factory.setButton();
		Thread.sleep(1000);
		alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		
		
	}

	@Then("^display gender error message$")
	public void display_gender_error_message() throws Throwable {
	    System.out.println("gender should be selected");
	}

	@When("^user enters address$")
	public void user_enters_address(DataTable arg1) throws Throwable {
		factory.getName().clear();
		factory.setName("Abhilash");
		Thread.sleep(1000);
		
		factory.getPhoneNumber().clear();
		factory.setPhoneNumber("9876543221");;
		Thread.sleep(1000);
		
		factory.getEmail().clear();
		factory.setEmail("abhilash@gmail.com");
		Thread.sleep(1000);
		
		factory.setGender2();
		
		factory.getAddr().clear();
		
		List<String> address=arg1.asList(String.class);
		String data;
		for (String addr:address) {
			data=addr;
			if(data!=null) {
				System.out.println("Matched...!");				
				}			
			else
			{
				System.out.println("not matched...!");
				/*alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();*/
			}
			
			factory.getAddr().clear();
			factory.setAddr(data);
			Thread.sleep(1000);
			factory.setButton();
			Thread.sleep(1000);
			
			alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
		
		}				
	}

	@Then("^display address box message$")
	public void display_address_box_message() throws Throwable {
	  System.out.println(" Address box error");
	}


}
