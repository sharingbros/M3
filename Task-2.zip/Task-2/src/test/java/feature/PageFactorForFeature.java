package feature;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactorForFeature {
	
	WebDriver wd;
	public PageFactorForFeature(WebDriver webdriver) {
		
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(name="name")
	@CacheLookup
	WebElement name1;
	
	@FindBy(name="phno")
	@CacheLookup
	WebElement phoneNumber;
	
	@FindBy(name="emailid")
	@CacheLookup
	WebElement email;
	@FindBy(id="males")
	WebElement gender1;
	
	@FindBy(id="females")
	WebElement gender2;
	
	@FindBy(id="address")
	@CacheLookup
	WebElement addr;
	
	@FindBy(id = "btn")
	WebElement button;


	public PageFactorForFeature() {
		super();
	}



	public WebElement getName() {
		return name1;
	}

	public void setName(String name) {
		name1.sendKeys(name);
	}

	public WebElement getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phno) {
		phoneNumber.sendKeys(phno);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String emailid) {
		email.sendKeys(emailid);
	}

	public WebElement getGender1() {
		return gender1;
	}

	public void setGender1() {
		gender1.click();
	}

	public WebElement getGender2() {
		return gender2;
	}

	public void setGender2() {
		gender2.click();
	}

	public WebElement getAddr() {
		return addr;
	}

	public void setAddr(String address) {
		addr.sendKeys(address);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
	
	
	

}
